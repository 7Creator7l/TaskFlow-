/* ========================================
   TASKFLOW — JAVASCRIPT
   PART 1/6
   ======================================== */

"use strict";

const STORAGE_KEY = "taskflow_tasks_v1";
const PROFILE_KEY = "taskflow_profile_v1";
const SETTINGS_KEY = "taskflow_settings_v1";

let tasks = loadTasks();
let profile = loadProfile();
let settings = loadSettings();

let currentPage = "home";
let editingTaskId = null;
let calendarDate = new Date();


/* ========================================
   HELPERS
   ======================================== */

function $(selector) {
    return document.querySelector(selector);
}

function $$(selector) {
    return document.querySelectorAll(selector);
}

function saveTasks() {
    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(tasks)
    );
}

function loadTasks() {
    try {
        const data = localStorage.getItem(
            STORAGE_KEY
        );

        return data
            ? JSON.parse(data)
            : [];
    } catch {
        return [];
    }
}

function loadProfile() {
    try {
        const data = localStorage.getItem(
            PROFILE_KEY
        );

        return data
            ? JSON.parse(data)
            : {
                name: "Пользователь",
                plan: "FREE"
            };
    } catch {
        return {
            name: "Пользователь",
            plan: "FREE"
        };
    }
}

function saveProfile() {
    localStorage.setItem(
        PROFILE_KEY,
        JSON.stringify(profile)
    );
}

function loadSettings() {
    try {
        const data = localStorage.getItem(
            SETTINGS_KEY
        );

        return data
            ? JSON.parse(data)
            : {
                notifications: true,
                dark: true
            };
    } catch {
        return {
            notifications: true,
            dark: true
        };
    }
}


/* ========================================
   ID
   ======================================== */

function createId() {
    return Date.now().toString(36)
        + Math.random()
            .toString(36)
            .slice(2, 8);
}


/* ========================================
   DATE
   ======================================== */

function todayISO() {
    const date = new Date();

    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, "0");

    const day = String(
        date.getDate()
    ).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

function formatDate(date) {
    if (!date) {
        return "";
    }

    const parts = date.split("-");

    if (parts.length !== 3) {
        return date;
    }

    return `${parts[2]}.${parts[1]}.${parts[0]}`;
}


/* ========================================
   TOAST
   ======================================== */

let toastTimer = null;

function showToast(message) {
    const toast = $("#toast");

    if (!toast) {
        return;
    }

    toast.textContent = message;
    toast.classList.remove("hidden");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.add("hidden");
    }, 2200);
}


/* ========================================
   NAVIGATION
   ======================================== */

function showPage(pageName) {
    const target = document.querySelector(
        `[data-page-section="${pageName}"]`
    );

    if (!target) {
        return;
    }

    $$(".page").forEach(page => {
        page.classList.remove("active");
    });

    target.classList.add("active");

    $$(".nav-item").forEach(item => {
        item.classList.toggle(
            "active",
            item.dataset.page === pageName
        );
    });

    currentPage = pageName;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    if (pageName === "statistics") {
        renderStatistics();
    }

    if (pageName === "calendar") {
        renderCalendar();
    }
}


/* ========================================
   NAV EVENTS
   ======================================== */

$$("[data-page]").forEach(button => {
    button.addEventListener(
        "click",
        () => {
            showPage(button.dataset.page);
            closePopups();
        }
    );
});


/* ========================================
   POPUPS
   ======================================== */

function closePopups() {
    $("#notificationPanel")
        ?.classList.add("hidden");

    $("#profilePanel")
        ?.classList.add("hidden");

    $("#searchPanel")
        ?.classList.add("hidden");
}


/* ========================================
   INIT
   ======================================== */

function init() {
    renderTasks();

    if (typeof renderStatistics === "function") {
        renderStatistics();
    }

    if (typeof renderCalendar === "function") {
        renderCalendar();
    }

    if (typeof renderNotifications === "function") {
        renderNotifications();
    }

    if (typeof applyProfile === "function") {
        applyProfile();
    }

    if (typeof applySettings === "function") {
        applySettings();
    }

    bindAddTaskButtons();
    bindTaskFilter();
    bindSearch();
    bindTaskForm();
}

document.addEventListener(
    "DOMContentLoaded",
    init
);
/* ========================================
   TASK CREATION
   ======================================== */

function openTaskModal() {

    const modal = $("#taskModal");

    if (!modal) return;

    editingTaskId = null;

    resetTaskForm();

    modal.classList.remove("hidden");

    setTimeout(() => {
        $("#taskTitle")?.focus();
    }, 100);
}


/* ========================================
   CLOSE MODAL
   ======================================== */

function closeTaskModal() {

    const modal = $("#taskModal");

    if (!modal) return;

    modal.classList.add("hidden");

    editingTaskId = null;
}


/* ========================================
   RESET FORM
   ======================================== */

function resetTaskForm() {

    const form = $("#taskForm");

    if (form) {
        form.reset();
    }

    const date = $("#taskDate");
    const time = $("#taskTime");

    if (date) {
        date.value = todayISO();
    }

    if (time) {

        const now = new Date();

        time.value =
            `${String(
                now.getHours()
            ).padStart(2, "0")}:` +
            `${String(
                now.getMinutes()
            ).padStart(2, "0")}`;
    }

    const preview =
        $("#taskPreviewTitle");

    if (preview) {
        preview.textContent =
            "Новая задача";
    }

    const previewDate =
        $("#taskPreviewDate");

    if (previewDate) {
        previewDate.textContent =
            "Выбери дату и время";
    }
}


/* ========================================
   PREVIEW
   ======================================== */

function updateTaskPreview() {

    const title =
        $("#taskTitle")?.value.trim();

    const date =
        $("#taskDate")?.value;

    const time =
        $("#taskTime")?.value;

    const preview =
        $("#taskPreviewTitle");

    const previewDate =
        $("#taskPreviewDate");

    if (preview) {
        preview.textContent =
            title || "Новая задача";
    }

    if (previewDate) {

        if (date && time) {

            previewDate.textContent =
                `${formatDate(date)} · ${time}`;

        } else {

            previewDate.textContent =
                "Выбери дату и время";
        }
    }
}


/* ========================================
   SAVE TASK
   ======================================== */

function saveTask(event) {

    event.preventDefault();

    const title =
        $("#taskTitle")?.value.trim();

    const date =
        $("#taskDate")?.value;

    const time =
        $("#taskTime")?.value;

    const priority =
        $("#taskPriority")?.value
        || "normal";

    const category =
        $("#taskCategory")?.value
        || "other";

    if (!title) {

        showToast(
            "Введите название задачи"
        );

        return;
    }

    if (!date) {

        showToast(
            "Выберите дату"
        );

        return;
    }

    if (!time) {

        showToast(
            "Выберите время"
        );

        return;
    }


    /* EDIT */

    if (editingTaskId) {

        const task =
            tasks.find(
                item =>
                    item.id ===
                    editingTaskId
            );

        if (!task) {
            return;
        }

        task.title = title;
        task.date = date;
        task.time = time;
        task.priority = priority;
        task.category = category;

        showToast(
            "Задача изменена ✓"
        );

    } else {

        /* NEW */

        tasks.push({

            id: createId(),

            title,

            date,

            time,

            priority,

            category,

            completed: false,

            createdAt:
                new Date().toISOString(),

            completedAt: null
        });

        showToast(
            "Задача создана ✓"
        );
    }


    saveTasks();

    closeTaskModal();

    renderTasks();

    renderStatistics();

    renderCalendar();

    renderNotifications();

    updateNotificationBadge();
}


/* ========================================
   TASK SORT
   ======================================== */

function sortTasks(list) {

    return [...list].sort(
        (a, b) => {

            const first =
                `${a.date} ${a.time}`;

            const second =
                `${b.date} ${b.time}`;

            return first.localeCompare(
                second
            );
        }
    );
}


/* ========================================
   TASK FILTER
   ======================================== */

function getVisibleTasks() {

    const filter =
        $("#taskFilter")?.value
        || "all";

    const search =
        $("#searchInput")?.value
            .trim()
            .toLowerCase()
        || "";

    let result = [...tasks];


    if (filter === "active") {

        result =
            result.filter(
                task =>
                    !task.completed
            );
    }


    if (filter === "completed") {

        result =
            result.filter(
                task =>
                    task.completed
            );
    }


    if (search) {

        result =
            result.filter(task => {

                const title =
                    task.title
                        .toLowerCase();

                const category =
                    String(
                        task.category
                    ).toLowerCase();

                return (
                    title.includes(search)
                    ||
                    category.includes(search)
                );
            });
    }


    return sortTasks(result);
}


/* ========================================
   TASK LABELS
   ======================================== */

function priorityText(priority) {

    const labels = {

        normal: "Обычный",

        important: "Важный",

        urgent: "Срочный"
    };

    return labels[priority]
        || labels.normal;
}


function categoryText(category) {

    const labels = {

        personal: "Личное",

        study: "Учёба",

        work: "Работа",

        other: "Другое"
    };

    return labels[category]
        || labels.other;
}


/* ========================================
   SAFE HTML
   ======================================== */

function escapeHTML(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
/* ========================================
   RENDER TASKS
   ======================================== */

function renderTasks() {

    const list = $(".task-list");

    if (!list) return;

    const visibleTasks =
        getVisibleTasks();

    if (!visibleTasks.length) {

        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">
                    ✨
                </div>

                <h3>
                    Задач пока нет
                </h3>

                <p>
                    Добавь первую задачу
                    и начни управлять
                    своим временем.
                </p>

                <button
                    class="secondary-btn"
                    type="button"
                    data-empty-add
                >
                    + Добавить задачу
                </button>
            </div>
        `;

        list
            .querySelector("[data-empty-add]")
            ?.addEventListener(
                "click",
                openTaskModal
            );

        return;
    }

    list.innerHTML =
        visibleTasks
            .map(createTaskHTML)
            .join("");

    bindTaskEvents();
}


/* ========================================
   TASK HTML
   ======================================== */

function createTaskHTML(task) {

    const completed =
        task.completed
            ? "completed"
            : "";

    const check =
        task.completed
            ? "✓"
            : "";

    return `
        <article
            class="task-item ${completed}"
            data-task-id="${escapeHTML(task.id)}"
        >

            <button
                class="task-check"
                type="button"
                data-action="complete"
                aria-label="Выполнить задачу"
            >
                ${check}
            </button>

            <div class="task-content">

                <div class="task-title">
                    ${escapeHTML(task.title)}
                </div>

                <div class="task-info">

                    <span>
                        ${formatDate(task.date)}
                        ·
                        ${escapeHTML(task.time)}
                    </span>

                    <span
                        class="
                            task-priority
                            ${escapeHTML(task.priority)}
                        "
                    >
                        ${priorityText(task.priority)}
                    </span>

                    <span class="task-category">
                        ${categoryText(task.category)}
                    </span>

                </div>

            </div>

            <div class="task-actions">

                <button
                    class="task-action"
                    type="button"
                    data-action="edit"
                    aria-label="Изменить"
                >
                    ✏️
                </button>

                <button
                    class="task-action delete"
                    type="button"
                    data-action="delete"
                    aria-label="Удалить"
                >
                    🗑️
                </button>

            </div>

        </article>
    `;
}


/* ========================================
   TASK EVENTS
   ======================================== */

function bindTaskEvents() {

    $$(".task-item").forEach(item => {

        const id =
            item.dataset.taskId;

        item
            .querySelector(
                '[data-action="complete"]'
            )
            ?.addEventListener(
                "click",
                () => toggleTask(id)
            );

        item
            .querySelector(
                '[data-action="edit"]'
            )
            ?.addEventListener(
                "click",
                () => editTask(id)
            );

        item
            .querySelector(
                '[data-action="delete"]'
            )
            ?.addEventListener(
                "click",
                () => deleteTask(id)
            );
    });
}


/* ========================================
   COMPLETE TASK
   ======================================== */

function toggleTask(id) {

    const task =
        tasks.find(
            item => item.id === id
        );

    if (!task) return;

    task.completed =
        !task.completed;

    task.completedAt =
        task.completed
            ? new Date().toISOString()
            : null;

    saveTasks();

    renderTasks();

    renderStatistics();

    renderCalendar();

    renderNotifications();

    showToast(
        task.completed
            ? "Задача выполнена ✓"
            : "Задача снова активна"
    );
}


/* ========================================
   EDIT TASK
   ======================================== */

function editTask(id) {

    const task =
        tasks.find(
            item => item.id === id
        );

    if (!task) return;

    editingTaskId = id;

    $("#taskTitle").value =
        task.title;

    $("#taskDate").value =
        task.date;

    $("#taskTime").value =
        task.time;

    $("#taskPriority").value =
        task.priority;

    $("#taskCategory").value =
        task.category;

    updateTaskPreview();

    $("#taskModal")
        ?.classList.remove("hidden");

    setTimeout(() => {
        $("#taskTitle")?.focus();
    }, 100);
}


/* ========================================
   DELETE TASK
   ======================================== */

function deleteTask(id) {

    const task =
        tasks.find(
            item => item.id === id
        );

    if (!task) return;

    const confirmed =
        window.confirm(
            `Удалить задачу "${task.title}"?`
        );

    if (!confirmed) {
        return;
    }

    tasks =
        tasks.filter(
            item => item.id !== id
        );

    saveTasks();

    renderTasks();

    renderStatistics();

    renderCalendar();

    renderNotifications();

    updateNotificationBadge();

    showToast(
        "Задача удалена"
    );
}


/* ========================================
   ADD BUTTONS
   ======================================== */

function bindAddTaskButtons() {

    const buttons = [
        "#addTaskBtn",
        "#addTaskButton",
        "[data-add-task]"
    ];

    buttons.forEach(selector => {

        $$(selector).forEach(button => {

            button.addEventListener(
                "click",
                openTaskModal
            );

        });

    });
}


/* ========================================
   TASK FILTER
   ======================================== */

function bindTaskFilter() {

    const filter =
        $("#taskFilter");

    if (!filter) return;

    filter.addEventListener(
        "change",
        renderTasks
    );
}


/* ========================================
   SEARCH
   ======================================== */

function bindSearch() {

    const input =
        $("#searchInput");

    if (!input) return;

    input.addEventListener(
        "input",
        renderTasks
    );
}


/* ========================================
   FORM EVENTS
   ======================================== */

function bindTaskForm() {

    $("#taskForm")
        ?.addEventListener(
            "submit",
            saveTask
        );

    $("#closeTaskModal")
        ?.addEventListener(
            "click",
            closeTaskModal
        );

    $("#cancelTaskBtn")
        ?.addEventListener(
            "click",
            closeTaskModal
        );

    $("#taskTitle")
        ?.addEventListener(
            "input",
            updateTaskPreview
        );

    $("#taskDate")
        ?.addEventListener(
            "change",
            updateTaskPreview
        );

    $("#taskTime")
        ?.addEventListener(
            "change",
            updateTaskPreview
        );
}
/* ========================================
   STATISTICS
   ======================================== */

function renderStatistics() {

    const total = tasks.length;

    const completed =
        tasks.filter(
            task => task.completed
        ).length;

    const active =
        total - completed;

    const percent =
        total === 0
            ? 0
            : Math.round(
                completed / total * 100
            );

    const totalEl =
        $("#totalTasks");

    const completedEl =
        $("#completedTasks");

    const activeEl =
        $("#activeTasks");

    const percentEl =
        $("#completionPercent");

    if (totalEl) {
        totalEl.textContent = total;
    }

    if (completedEl) {
        completedEl.textContent =
            completed;
    }

    if (activeEl) {
        activeEl.textContent =
            active;
    }

    if (percentEl) {
        percentEl.textContent =
            `${percent}%`;
    }

    $$(".progress-bar")
        .forEach(bar => {
            bar.style.width =
                `${percent}%`;
        });
}


/* ========================================
   CALENDAR
   ======================================== */

function renderCalendar() {

    const grid =
        $("#calendarGrid");

    if (!grid) return;

    const year =
        calendarDate.getFullYear();

    const month =
        calendarDate.getMonth();

    const firstDay =
        new Date(
            year,
            month,
            1
        ).getDay();

    const days =
        new Date(
            year,
            month + 1,
            0
        ).getDate();

    const offset =
        firstDay === 0
            ? 6
            : firstDay - 1;

    grid.innerHTML = "";

    const names = [
        "Пн",
        "Вт",
        "Ср",
        "Чт",
        "Пт",
        "Сб",
        "Вс"
    ];

    names.forEach(name => {

        const el =
            document.createElement(
                "div"
            );

        el.className =
            "calendar-day-name";

        el.textContent = name;

        grid.appendChild(el);
    });

    for (
        let i = 0;
        i < offset;
        i++
    ) {

        const empty =
            document.createElement(
                "div"
            );

        empty.className =
            "calendar-day empty";

        grid.appendChild(empty);
    }

    for (
        let day = 1;
        day <= days;
        day++
    ) {

        const el =
            document.createElement(
                "button"
            );

        el.type = "button";

        el.className =
            "calendar-day";

        const date =
            `${year}-` +
            `${String(month + 1)
                .padStart(2, "0")}-` +
            `${String(day)
                .padStart(2, "0")}`;

        const hasTasks =
            tasks.some(
                task =>
                    task.date === date
            );

        if (hasTasks) {
            el.classList.add(
                "has-tasks"
            );
        }

        if (date === todayISO()) {
            el.classList.add(
                "today"
            );
        }

        el.textContent = day;

        el.addEventListener(
            "click",
            () => {

                const dayTasks =
                    tasks.filter(
                        task =>
                            task.date === date
                    );

                if (!dayTasks.length) {

                    showToast(
                        "На этот день задач нет"
                    );

                    return;
                }

                showToast(
                    `Задач на ${formatDate(date)}: ${dayTasks.length}`
                );
            }
        );

        grid.appendChild(el);
    }

    updateCalendarTitle(
        year,
        month
    );
}


/* ========================================
   CALENDAR TITLE
   ======================================== */

function updateCalendarTitle(
    year,
    month
) {

    const title =
        $("#calendarTitle");

    if (!title) return;

    const months = [
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь"
    ];

    title.textContent =
        `${months[month]} ${year}`;
}


/* ========================================
   CALENDAR CONTROLS
   ======================================== */

function bindCalendarControls() {

    $("#calendarPrev")
        ?.addEventListener(
            "click",
            () => {

                calendarDate.setMonth(
                    calendarDate.getMonth() - 1
                );

                renderCalendar();
            }
        );

    $("#calendarNext")
        ?.addEventListener(
            "click",
            () => {

                calendarDate.setMonth(
                    calendarDate.getMonth() + 1
                );

                renderCalendar();
            }
        );
}


/* ========================================
   NOTIFICATIONS
   ======================================== */

function getNotifications() {

    const result = [];

    const active =
        tasks.filter(
            task => !task.completed
        );

    active.slice(0, 5)
        .forEach(task => {

            result.push({
                title:
                    `Задача: ${task.title}`,

                text:
                    `${formatDate(task.date)} · ${task.time}`
            });
        });

    return result;
}


/* ========================================
   RENDER NOTIFICATIONS
   ======================================== */

function renderNotifications() {

    const container =
        $("#notificationList");

    if (!container) return;

    const notifications =
        getNotifications();

    if (!notifications.length) {

        container.innerHTML = `
            <div class="empty-notifications">
                Всё чисто — новых
                уведомлений нет.
            </div>
        `;

        updateNotificationBadge();

        return;
    }

    container.innerHTML =
        notifications.map(item => `
            <div class="notification-item">
                <strong>
                    ${escapeHTML(item.title)}
                </strong>

                <span>
                    ${escapeHTML(item.text)}
                </span>
            </div>
        `).join("");

    updateNotificationBadge();
}


/* ========================================
   NOTIFICATION BADGE
   ======================================== */

function updateNotificationBadge() {

    const badge =
        $("#notificationBadge");

    if (!badge) return;

    const count =
        tasks.filter(
            task => !task.completed
        ).length;

    badge.textContent =
        count > 99
            ? "99+"
            : count;

    badge.classList.toggle(
        "hidden",
        count === 0
    );
}
/* ========================================
   PROFILE
   ======================================== */

function applyProfile() {

    const name =
        profile.name || "Пользователь";

    $$(".profile-name")
        .forEach(el => {
            el.textContent = name;
        });

    $$(".profile-plan")
        .forEach(el => {
            el.textContent =
                profile.plan || "FREE";
        });

    $$(".mini-avatar, .profile-avatar")
        .forEach(el => {
            el.textContent =
                name.charAt(0).toUpperCase();
        });
}


/* ========================================
   SAVE PROFILE
   ======================================== */

function saveProfileForm(event) {

    event.preventDefault();

    const input =
        $("#profileName");

    if (!input) return;

    const name =
        input.value.trim();

    if (!name) {

        showToast(
            "Введите имя"
        );

        return;
    }

    profile.name = name;

    saveProfile();

    applyProfile();

    showToast(
        "Профиль сохранён ✓"
    );
}


/* ========================================
   SETTINGS
   ======================================== */

function applySettings() {

    const notificationSwitch =
        $("#notificationsSwitch");

    if (notificationSwitch) {

        notificationSwitch.checked =
            settings.notifications;
    }
}


/* ========================================
   SETTINGS EVENTS
   ======================================== */

function bindSettings() {

    $("#notificationsSwitch")
        ?.addEventListener(
            "change",
            event => {

                settings.notifications =
                    event.target.checked;

                localStorage.setItem(
                    SETTINGS_KEY,
                    JSON.stringify(settings)
                );

                showToast(
                    settings.notifications
                        ? "Уведомления включены"
                        : "Уведомления выключены"
                );
            }
        );
}


/* ========================================
   PROFILE EVENTS
   ======================================== */

function bindProfile() {

    const input =
        $("#profileName");

    if (input) {
        input.value =
            profile.name || "";
    }

    $("#profileForm")
        ?.addEventListener(
            "submit",
            saveProfileForm
        );
}


/* ========================================
   PREMIUM
   ======================================== */

const PLANS = {

    FREE: {
        name: "FREE",
        price: "$0",
        period: "навсегда"
    },

    PREMIUM: {
        name: "PREMIUM",
        price: "$5.99",
        period: "в месяц"
    },

    LEGEND: {
        name: "LEGEND",
        price: "$8.29",
        period: "в месяц"
    }
};


/* ========================================
   PLAN UI
   ======================================== */

function renderPlans() {

    const current =
        profile.plan || "FREE";

    $$(".plan-card")
        .forEach(card => {

            const plan =
                card.dataset.plan;

            const button =
                card.querySelector(
                    "[data-buy-plan]"
                );

            if (!button) return;

            if (plan === current) {

                button.textContent =
                    "Текущий план";

                button.disabled = true;

            } else {

                button.textContent =
                    `Выбрать ${plan}`;

                button.disabled = false;
            }
        });
}


/* ========================================
   SELECT PLAN
   ======================================== */

function selectPlan(plan) {

    if (!PLANS[plan]) {
        return;
    }

    if (plan === "FREE") {

        profile.plan = "FREE";

        saveProfile();

        applyProfile();

        renderPlans();

        showToast(
            "План FREE активирован"
        );

        return;
    }

    openPaymentModal(plan);
}


/* ========================================
   PAYMENT MODAL
   ======================================== */

function openPaymentModal(plan) {

    const data =
        PLANS[plan];

    if (!data) return;

    const modal =
        $("#paymentModal");

    if (!modal) {

        showToast(
            `${data.name}: ${data.price} ${data.period}`
        );

        return;
    }

    const title =
        modal.querySelector(
            "[data-payment-title]"
        );

    const price =
        modal.querySelector(
            "[data-payment-price]"
        );

    if (title) {
        title.textContent =
            data.name;
    }

    if (price) {
        price.textContent =
            `${data.price} / ${data.period}`;
    }

    modal.dataset.plan = plan;

    modal.classList.remove(
        "hidden"
    );
}


/* ========================================
   CLOSE PAYMENT
   ======================================== */

function closePaymentModal() {

    $("#paymentModal")
        ?.classList.add("hidden");
}


/* ========================================
   PLAN EVENTS
   ======================================== */

function bindPlans() {

    $$(".plan-card")
        .forEach(card => {

            const plan =
                card.dataset.plan;

            card.querySelector(
                "[data-buy-plan]"
            )?.addEventListener(
                "click",
                () => selectPlan(plan)
            );
        });

    $("#closePaymentModal")
        ?.addEventListener(
            "click",
            closePaymentModal
        );

    $("#cancelPayment")
        ?.addEventListener(
            "click",
            closePaymentModal
        );

    $("#paymentModal")
        ?.addEventListener(
            "click",
            event => {

                if (
                    event.target.id ===
                    "paymentModal"
                ) {
                    closePaymentModal();
                }
            }
        );
}


/* ========================================
   DEMO PAYMENT
   ======================================== */

function confirmPayment() {

    const modal =
        $("#paymentModal");

    if (!modal) return;

    const plan =
        modal.dataset.plan;

    if (!PLANS[plan]) {
        return;
    }

    /*
       Здесь пока только локальная
       демонстрация выбора тарифа.

       Реальную оплату подключим
       позже через платёжную систему.
    */

    profile.plan = plan;

    saveProfile();

    applyProfile();

    renderPlans();

    closePaymentModal();

    showToast(
        `${PLANS[plan].name} активирован ✓`
    );
}
/* ========================================
   FINAL EVENTS
   ======================================== */

function bindFinalEvents() {

    bindAddTaskButtons();
    bindTaskFilter();
    bindSearch();
    bindTaskForm();

    bindCalendarControls();
    bindSettings();
    bindProfile();
    bindPlans();


    /* PAYMENT */

    $("#confirmPayment")
        ?.addEventListener(
            "click",
            confirmPayment
        );


    /* NOTIFICATIONS */

    $("#notificationBtn")
        ?.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                $("#notificationPanel")
                    ?.classList.toggle(
                        "hidden"
                    );

                $("#profilePanel")
                    ?.classList.add(
                        "hidden"
                    );
            }
        );


    /* PROFILE BUTTON */

    $("#profileBtn")
        ?.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                $("#profilePanel")
                    ?.classList.toggle(
                        "hidden"
                    );

                $("#notificationPanel")
                    ?.classList.add(
                        "hidden"
                    );
            }
        );


    /* CLOSE POPUPS */

    document.addEventListener(
        "click",
        event => {

            const notification =
                $("#notificationPanel");

            const profilePanel =
                $("#profilePanel");

            const notificationBtn =
                $("#notificationBtn");

            const profileBtn =
                $("#profileBtn");


            if (
                notification &&
                !notification.contains(
                    event.target
                ) &&
                notificationBtn &&
                !notificationBtn.contains(
                    event.target
                )
            ) {
                notification.classList.add(
                    "hidden"
                );
            }


            if (
                profilePanel &&
                !profilePanel.contains(
                    event.target
                ) &&
                profileBtn &&
                !profileBtn.contains(
                    event.target
                )
            ) {
                profilePanel.classList.add(
                    "hidden"
                );
            }
        }
    );


    /* ESC */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape") {
                return;
            }

            closeTaskModal();
            closePaymentModal();
            closePopups();
        }
    );


    /* MODAL BACKDROP */

    $("#taskModal")
        ?.addEventListener(
            "click",
            event => {

                if (
                    event.target.id ===
                    "taskModal"
                ) {
                    closeTaskModal();
                }
            }
        );
}


/* ========================================
   CLEAR ALL TASKS
   ======================================== */

function clearAllTasks() {

    if (!tasks.length) {

        showToast(
            "Задач уже нет"
        );

        return;
    }

    const confirmed =
        window.confirm(
            "Удалить все задачи?"
        );

    if (!confirmed) {
        return;
    }

    tasks = [];

    saveTasks();

    renderTasks();
    renderStatistics();
    renderCalendar();
    renderNotifications();
    updateNotificationBadge();

    showToast(
        "Все задачи удалены"
    );
}


/* ========================================
   FINAL INIT
   ======================================== */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        bindFinalEvents();

        applyProfile();
        applySettings();

        renderPlans();

        renderTasks();
        renderStatistics();
        renderCalendar();
        renderNotifications();

        updateNotificationBadge();

    },
    {
        once: true
    }
);