# TaskFlow — Notifications v1

This version adds native Android notifications.

What changed:
- `POST_NOTIFICATIONS` permission for Android 13+.
- A `TaskFlow` notification channel.
- A one-time test notification after permission is granted.
- Version bumped to 1.0.1.

Test:
1. Build a new APK/AAB.
2. Install the new APK.
3. On first launch, tap **Разрешить** when Android asks for notifications.
4. You should receive: **TaskFlow — Уведомления работают ✅**.
5. Android Settings → Apps → TaskFlow → Notifications should now show enabled notification controls.

This is the permission/test stage. Actual task-time reminders are the next step.
