# TaskFlow Android / AAB

Это Android-обёртка для исходного веб-приложения TaskFlow из CodePen.

## Что внутри
- `app/src/main/assets/www/` — исходные `index.html`, `style.css`, `script.js`.
- `MainActivity.java` — локальный Android WebView с включёнными JavaScript и DOM Storage.
- Gradle-конфигурация для Android App Bundle.

## Сборка AAB
Открой папку проекта в Android Studio и дождись синхронизации Gradle.
Затем: Build → Generate Signed Bundle / APK → Android App Bundle.

Для тестовой сборки можно использовать Gradle task `bundleDebug`.
Для Google Play нужен release AAB, подписанный вашим ключом.
