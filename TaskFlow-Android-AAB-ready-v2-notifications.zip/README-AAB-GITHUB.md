# TASKFLOW — Android AAB

This project contains the TASKFLOW Android WebView wrapper.

## Build an AAB with GitHub Actions

1. Upload the contents of this project to a GitHub repository.
2. Open the repository and select **Actions**.
3. Select **Build TaskFlow AAB**.
4. Press **Run workflow**.
5. When the workflow finishes, open the run and download the artifact:
   `taskflow-debug-aab`.

The artifact contains:
`app-debug.aab`

Note: this is a debug AAB. A Google Play release normally needs a release-signed build.
