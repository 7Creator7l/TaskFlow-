/* ===== QUICKLIST ===== */

"use strict";

const STORAGE_KEY = "quicklist_data_v1";

const DEFAULT_CATEGORIES = [
  {
    id: "personal",
    name: "Личное",
    icon: "👤"
  },
  {
    id: "work",
    name: "Работа",
    icon: "💼"
  },
  {
    id: "shopping",
    name: "Покупки",
    icon: "🛒"
  },
  {
    id: "study",
    name: "Учёба",
    icon: "📚"
  }
];

const DEFAULT_TIPS = [
  "Начни с самой простой задачи.",
  "Небольшие шаги тоже двигают тебя вперёд.",
  "Закрывай задачи по одной, не пытаясь сделать всё сразу.",
  "Если задача большая — раздели её на несколько маленьких.",
  "Проверь список и убери то, что больше не нужно.",
  "Отмечай выполненные задачи — так прогресс заметнее.",
  "Сначала сделай то, что занимает меньше всего времени.",
  "Оставляй список достаточно коротким, чтобы он был удобным."
];

let state = createDefaultState();
let currentScreen = "home";
let currentCategory = "all";
let selectedTaskId = null;
let editingTaskId = null;
let confirmAction = null;
let currentSort = "newest";
let searchQuery = "";
let tipIndex = 0;

/* ===== DOM HELPERS ===== */

const $ = (selector) => document.querySelector(selector);

const $$ = (selector) => Array.from(document.querySelectorAll(selector));

function getElement(id) {
  return document.getElementById(id);
}

/* ===== DEFAULT STATE ===== */

function createDefaultState() {
  return {
    tasks: [],
    archive: [],
    categories: [...DEFAULT_CATEGORIES],
    settings: {
      darkTheme: false,
      animations: true,
      defaultCategory: "personal",
      sort: "newest",
      startScreen: "home"
    },
    tipIndex: 0
  };
}

/* ===== STORAGE ===== */

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);

    if (!raw) {
      state = createDefaultState();
      return;
    }

    const parsed = JSON.parse(raw);
    state = normalizeState(parsed);
  } catch (error) {
    console.error("QuickList: ошибка загрузки данных", error);
    state = createDefaultState();
  }
}

function saveState() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(state)
    );
  } catch (error) {
    console.error("QuickList: ошибка сохранения", error);
  }
}

function normalizeState(data) {
  const base = createDefaultState();

  if (!data || typeof data !== "object") {
    return base;
  }

  const normalized = {
    tasks: Array.isArray(data.tasks) ? data.tasks : [],
    archive: Array.isArray(data.archive) ? data.archive : [],
    categories: Array.isArray(data.categories)
      ? data.categories
      : base.categories,
    settings: {
      ...base.settings,
      ...(data.settings || {})
    },
    tipIndex: Number.isInteger(data.tipIndex)
      ? data.tipIndex
      : 0
  };

  normalized.categories = normalizeCategories(
    normalized.categories
  );

  normalized.tasks = normalized.tasks
    .map(normalizeTask)
    .filter(Boolean);

  normalized.archive = normalized.archive
    .map(normalizeTask)
    .filter(Boolean);

  return normalized;
}

function normalizeCategories(categories) {
  const result = [];

  for (const category of categories) {
    if (!category || !category.id || !category.name) {
      continue;
    }

    if (result.some(item => item.id === category.id)) {
      continue;
    }

    result.push({
      id: String(category.id),
      name: String(category.name),
      icon: category.icon || "📁"
    });
  }

  for (const defaultCategory of DEFAULT_CATEGORIES) {
    if (!result.some(item => item.id === defaultCategory.id)) {
      result.push({ ...defaultCategory });
    }
  }

  return result;
}
/* ===== TASK NORMALIZATION ===== */

function normalizeTask(task) {
  if (!task || typeof task !== "object") {
    return null;
  }

  const title = String(task.title || "").trim();

  if (!title) {
    return null;
  }

  const createdAt = Number(task.createdAt);

  return {
    id: String(task.id || createId()),
    title,
    category: String(task.category || "personal"),
    completed: Boolean(task.completed),
    createdAt: Number.isFinite(createdAt)
      ? createdAt
      : Date.now(),
    completedAt: task.completedAt
      ? Number(task.completedAt)
      : null,
    updatedAt: task.updatedAt
      ? Number(task.updatedAt)
      : null
  };
}

/* ===== ID ===== */

function createId() {
  if (
    typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
  ) {
    return crypto.randomUUID();
  }

  return (
    Date.now().toString(36) +
    Math.random().toString(36).slice(2)
  );
}

/* ===== CATEGORY HELPERS ===== */

function getCategory(categoryId) {
  return state.categories.find(
    category => category.id === categoryId
  ) || null;
}

function getCategoryName(categoryId) {
  if (categoryId === "all") {
    return "Все";
  }

  const category = getCategory(categoryId);

  return category ? category.name : "Без категории";
}

function getCategoryIcon(categoryId) {
  if (categoryId === "all") {
    return "📋";
  }

  const category = getCategory(categoryId);

  return category ? category.icon : "📁";
}

/* ===== TASK HELPERS ===== */

function getTask(taskId) {
  return state.tasks.find(
    task => task.id === taskId
  ) || null;
}

function getArchiveTask(taskId) {
  return state.archive.find(
    task => task.id === taskId
  ) || null;
}

function getActiveTasks() {
  return state.tasks.slice();
}

function getVisibleTasks() {
  let tasks = getActiveTasks();

  if (currentCategory !== "all") {
    tasks = tasks.filter(
      task => task.category === currentCategory
    );
  }

  return sortTaskArray(tasks, currentSort);
}

function sortTaskArray(tasks, sortType) {
  const result = tasks.slice();

  switch (sortType) {
    case "oldest":
      return result.sort(
        (a, b) => a.createdAt - b.createdAt
      );

    case "completed":
      return result.sort((a, b) => {
        if (a.completed !== b.completed) {
          return Number(a.completed) - Number(b.completed);
        }

        return b.createdAt - a.createdAt;
      });

    case "alphabetical":
      return result.sort((a, b) =>
        a.title.localeCompare(
          b.title,
          "ru",
          { sensitivity: "base" }
        )
      );

    case "newest":
    default:
      return result.sort(
        (a, b) => b.createdAt - a.createdAt
      );
  }
}

/* ===== COUNTS ===== */

function getCompletedCount() {
  return state.tasks.filter(
    task => task.completed
  ).length;
}

function getTotalCount() {
  return state.tasks.length;
}

function getCategoryCount(categoryId) {
  return state.tasks.filter(
    task => task.category === categoryId
  ).length;
}

function getProgressPercent() {
  const total = getTotalCount();

  if (total === 0) {
    return 0;
  }

  return Math.round(
    (getCompletedCount() / total) * 100
  );
}

/* ===== TEXT HELPERS ===== */

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatDate(timestamp) {
  if (!timestamp) {
    return "—";
  }

  const date = new Date(timestamp);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString(
    "ru-RU",
    {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    }
  );
}

function formatTime(timestamp) {
  if (!timestamp) {
    return "—";
  }

  const date = new Date(timestamp);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleTimeString(
    "ru-RU",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );
}

/* ===== SCREEN MANAGEMENT ===== */

function showScreen(screenName) {
  const screens = $$(".screen");

  screens.forEach(screen => {
    screen.classList.toggle(
      "active",
      screen.id === `${screenName}Screen`
    );
  });

  currentScreen = screenName;

  updateNavigation();
}

function updateNavigation() {
  $$(".nav-item").forEach(item => {
    const target = item.dataset.screen;

    item.classList.toggle(
      "active",
      target === currentScreen
    );
  });
}

/* ===== BODY SETTINGS ===== */

function applySettings() {
  document.body.classList.toggle(
    "dark-theme",
    Boolean(state.settings.darkTheme)
  );

  document.body.classList.toggle(
    "animations-off",
    !Boolean(state.settings.animations)
  );
}

/* ===== END BLOCK 2 ===== */
/* ===== RENDER: PROGRESS ===== */

function renderProgress() {
  const completed = getCompletedCount();
  const total = getTotalCount();
  const percent = getProgressPercent();

  const progressValue = getElement("progressValue");
  const progressBar = getElement("progressBar");
  const completedCount = getElement("completedTaskCount");
  const totalCount = getElement("totalTaskCount");

  if (progressValue) {
    progressValue.textContent = `${percent}%`;
  }

  if (progressBar) {
    progressBar.style.width = `${percent}%`;
    progressBar.setAttribute(
      "aria-valuenow",
      String(percent)
    );
  }

  if (completedCount) {
    completedCount.textContent = String(completed);
  }

  if (totalCount) {
    totalCount.textContent = String(total);
  }
}

/* ===== RENDER: CATEGORY COUNTS ===== */

function renderCategoryCounts() {
  const counters = {
    allCategoryCount: state.tasks.length,
    personalCategoryCount: getCategoryCount("personal"),
    workCategoryCount: getCategoryCount("work"),
    shoppingCategoryCount: getCategoryCount("shopping"),
    studyCategoryCount: getCategoryCount("study")
  };

  Object.entries(counters).forEach(
    ([id, value]) => {
      const element = getElement(id);

      if (element) {
        element.textContent = String(value);
      }
    }
  );
}

/* ===== RENDER: CATEGORIES ===== */

function renderCategoryGrid() {
  const grid = getElement("categoryGrid");

  if (!grid) {
    return;
  }

  const staticCards = Array.from(
    grid.querySelectorAll(".category-card")
  );

  staticCards.forEach(card => {
    const category = card.dataset.category;

    if (!category || category === "all") {
      return;
    }

    const known = getCategory(category);

    if (!known) {
      card.remove();
    }
  });

  state.categories.forEach(category => {
    if (
      ["personal", "work", "shopping", "study"]
        .includes(category.id)
    ) {
      return;
    }

    let card = grid.querySelector(
      `.category-card[data-category="${CSS.escape(category.id)}"]`
    );

    if (!card) {
      card = document.createElement("button");
      card.type = "button";
      card.className = "category-card";
      card.dataset.category = category.id;

      card.innerHTML = `
        <span class="category-icon">${escapeHtml(category.icon)}</span>
        <span class="category-name">${escapeHtml(category.name)}</span>
        <span class="category-count">0</span>
      `;

      grid.appendChild(card);
    }

    const count = getCategoryCount(category.id);
    const countElement =
      card.querySelector(".category-count");

    if (countElement) {
      countElement.textContent = String(count);
    }
  });

  $$(".category-card").forEach(card => {
    card.classList.toggle(
      "active",
      card.dataset.category === currentCategory
    );
  });
}

/* ===== RENDER: TASK LIST ===== */

function renderTaskList() {
  const list = getElement("taskList");
  const emptyState = getElement("emptyState");

  if (!list) {
    return;
  }

  const tasks = getVisibleTasks();

  list.innerHTML = "";

  if (tasks.length === 0) {
    if (emptyState) {
      emptyState.classList.remove("hidden");
    }

    return;
  }

  if (emptyState) {
    emptyState.classList.add("hidden");
  }

  tasks.forEach(task => {
    list.appendChild(createTaskElement(task));
  });
}

function createTaskElement(task) {
  const item = document.createElement("article");

  item.className = "task-item";
  item.dataset.taskId = task.id;

  if (task.completed) {
    item.classList.add("completed");
  }

  const categoryName = getCategoryName(task.category);
  const categoryIcon = getCategoryIcon(task.category);

  item.innerHTML = `
    <button
      type="button"
      class="task-check"
      data-action="toggle"
      aria-label="${task.completed ? "Вернуть задачу" : "Выполнить задачу"}"
      aria-pressed="${task.completed}"
    >
      ${task.completed ? "✓" : ""}
    </button>

    <div class="task-content" data-action="details">
      <div class="task-title">${escapeHtml(task.title)}</div>

      <div class="task-meta">
        <span class="task-category">
          ${escapeHtml(categoryIcon)}
          ${escapeHtml(categoryName)}
        </span>

        <span class="task-date">
          ${escapeHtml(formatDate(task.createdAt))}
        </span>
      </div>
    </div>

    <div class="task-actions">
      <button
        type="button"
        class="icon-button"
        data-action="edit"
        aria-label="Редактировать"
      >
        ✏️
      </button>

      <button
        type="button"
        class="icon-button danger"
        data-action="delete"
        aria-label="Удалить"
      >
        🗑️
      </button>
    </div>
  `;

  return item;
}

/* ===== FULL RENDER ===== */

function renderAll() {
  renderProgress();
  renderCategoryCounts();
  renderCategoryGrid();
  renderTaskList();
  renderArchive();
  renderSettings();
  renderCategoriesManager();
  updateSortText();
  renderTip();
}

/* ===== TASK CREATION ===== */

function addTask(title, category) {
  const cleanTitle = String(title || "").trim();

  if (!cleanTitle) {
    showMessage(
      "Пустая задача",
      "Напиши название задачи."
    );
    return false;
  }

  const validCategory =
    getCategory(category) ? category : "personal";

  const task = {
    id: createId(),
    title: cleanTitle,
    category: validCategory,
    completed: false,
    createdAt: Date.now(),
    completedAt: null,
    updatedAt: null
  };

  state.tasks.push(task);
  saveState();
  renderAll();

  showToast(
    "✓",
    "Задача добавлена"
  );

  return true;
}

/* ===== TASK TOGGLE ===== */

function toggleTask(taskId) {
  const task = getTask(taskId);

  if (!task) {
    return;
  }

  task.completed = !task.completed;
  task.completedAt = task.completed
    ? Date.now()
    : null;
  task.updatedAt = Date.now();

  saveState();
  renderAll();

  showToast(
    task.completed ? "✓" : "↶",
    task.completed
      ? "Задача выполнена"
      : "Задача возвращена"
  );
}

/* ===== END BLOCK 3 ===== */
/* ===== TASK EDITING ===== */

function openEditTask(taskId) {
  const task = getTask(taskId);

  if (!task) {
    return;
  }

  editingTaskId = taskId;

  const input = getElement("editTaskInput");
  const select = getElement("editCategorySelect");

  if (input) {
    input.value = task.title;
  }

  populateCategorySelect(
    select,
    task.category
  );

  openModal("editTaskModal");

  if (input) {
    setTimeout(() => {
      input.focus();
      input.select();
    }, 50);
  }
}

function saveEditedTask() {
  if (!editingTaskId) {
    return;
  }

  const task = getTask(editingTaskId);
  const input = getElement("editTaskInput");
  const select = getElement("editCategorySelect");

  if (!task || !input) {
    return;
  }

  const title = input.value.trim();

  if (!title) {
    showMessage(
      "Пустое название",
      "Введите название задачи."
    );
    return;
  }

  const category =
    select && getCategory(select.value)
      ? select.value
      : task.category;

  task.title = title;
  task.category = category;
  task.updatedAt = Date.now();

  saveState();
  closeModal("editTaskModal");

  editingTaskId = null;

  renderAll();

  showToast(
    "✓",
    "Задача изменена"
  );
}

/* ===== TASK DELETE ===== */

function requestDeleteTask(taskId) {
  const task = getTask(taskId);

  if (!task) {
    return;
  }

  confirmAction = {
    type: "deleteTask",
    taskId
  };

  openConfirmModal(
    "Удалить задачу?",
    `Задача «${task.title}» будет удалена.`
  );
}

function deleteTask(taskId) {
  const index = state.tasks.findIndex(
    task => task.id === taskId
  );

  if (index === -1) {
    return;
  }

  const [task] = state.tasks.splice(index, 1);

  state.archive.push({
    ...task,
    updatedAt: Date.now()
  });

  saveState();
  renderAll();

  if (selectedTaskId === taskId) {
    selectedTaskId = null;
    showScreen("home");
  }

  showToast(
    "🗑️",
    "Задача перемещена в архив"
  );
}

/* ===== TASK DETAILS ===== */

function openTaskDetails(taskId) {
  const task = getTask(taskId);

  if (!task) {
    return;
  }

  selectedTaskId = taskId;

  const icon = getElement("detailsStatusIcon");
  const status = getElement("detailsStatusText");
  const title = getElement("detailsTaskTitle");
  const date = getElement("detailsTaskDate");
  const category = getElement("detailsTaskCategory");
  const time = getElement("detailsTaskTime");
  const toggle = getElement("toggleTaskDetailsButton");

  if (icon) {
    icon.textContent = task.completed ? "✓" : "○";
  }

  if (status) {
    status.textContent = task.completed
      ? "Выполнено"
      : "В процессе";
  }

  if (title) {
    title.textContent = task.title;
  }

  if (date) {
    date.textContent = formatDate(task.createdAt);
  }

  if (category) {
    category.textContent =
      `${getCategoryIcon(task.category)} ${getCategoryName(task.category)}`;
  }

  if (time) {
    time.textContent = formatTime(task.createdAt);
  }

  if (toggle) {
    toggle.textContent = task.completed
      ? "Вернуть задачу"
      : "Выполнить";
  }

  showScreen("taskDetails");
}

function toggleSelectedTask() {
  if (!selectedTaskId) {
    return;
  }

  toggleTask(selectedTaskId);

  const task = getTask(selectedTaskId);

  if (task) {
    openTaskDetails(selectedTaskId);
  }
}

function editSelectedTask() {
  if (!selectedTaskId) {
    return;
  }

  openEditTask(selectedTaskId);
}

function deleteSelectedTask() {
  if (!selectedTaskId) {
    return;
  }

  requestDeleteTask(selectedTaskId);
}

/* ===== CATEGORY SELECTS ===== */

function populateCategorySelect(select, selectedId) {
  if (!select) {
    return;
  }

  select.innerHTML = "";

  state.categories.forEach(category => {
    const option = document.createElement("option");

    option.value = category.id;
    option.textContent =
      `${category.icon} ${category.name}`;

    option.selected =
      category.id === selectedId;

    select.appendChild(option);
  });
}

function renderTaskCategorySelects() {
  populateCategorySelect(
    getElement("modalCategorySelect"),
    state.settings.defaultCategory
  );

  populateCategorySelect(
    getElement("editCategorySelect"),
    editingTaskId
      ? getTask(editingTaskId)?.category
      : state.settings.defaultCategory
  );
}

/* ===== ADD TASK MODAL ===== */

function openAddTaskModal() {
  renderTaskCategorySelects();

  const input = getElement("modalTaskInput");

  openModal("addTaskModal");

  if (input) {
    input.value = "";

    setTimeout(() => {
      input.focus();
    }, 50);
  }
}

function saveModalTask() {
  const input = getElement("modalTaskInput");
  const select = getElement("modalCategorySelect");

  if (!input) {
    return;
  }

  const success = addTask(
    input.value,
    select ? select.value : state.settings.defaultCategory
  );

  if (success) {
    closeModal("addTaskModal");
    input.value = "";
  }
}

/* ===== END BLOCK 4 ===== */
/* ===== MODAL MANAGEMENT ===== */

function openModal(modalId) {
  const modal = getElement(modalId);

  if (!modal) {
    return;
  }

  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("no-scroll");
}

function closeModal(modalId) {
  const modal = getElement(modalId);

  if (!modal) {
    return;
  }

  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");

  if (!$$(".modal.open").length) {
    document.body.classList.remove("no-scroll");
  }
}

function closeAllModals() {
  $$(".modal.open").forEach(modal => {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  });

  document.body.classList.remove("no-scroll");
}

/* ===== CONFIRMATION ===== */

function openConfirmModal(title, text) {
  const titleElement = getElement("confirmTitle");
  const textElement = getElement("confirmText");

  if (titleElement) {
    titleElement.textContent = title;
  }

  if (textElement) {
    textElement.textContent = text;
  }

  openModal("confirmModal");
}

function executeConfirmAction() {
  if (!confirmAction) {
    closeModal("confirmModal");
    return;
  }

  const action = confirmAction;
  confirmAction = null;

  closeModal("confirmModal");

  if (action.type === "deleteTask") {
    deleteTask(action.taskId);
    return;
  }

  if (action.type === "clearCompleted") {
    clearCompletedTasks();
    return;
  }

  if (action.type === "clearArchive") {
    clearArchive();
    return;
  }

  if (action.type === "resetData") {
    resetData();
  }
}

/* ===== MESSAGE MODAL ===== */

function showMessage(title, text) {
  const titleElement = getElement("messageTitle");
  const textElement = getElement("messageText");

  if (titleElement) {
    titleElement.textContent = title;
  }

  if (textElement) {
    textElement.textContent = text;
  }

  openModal("messageModal");
}

/* ===== TOAST ===== */

let toastTimer = null;

function showToast(icon, message) {
  const toast = getElement("toast");
  const toastIcon = getElement("toastIcon");
  const toastMessage = getElement("toastMessage");

  if (!toast) {
    return;
  }

  if (toastIcon) {
    toastIcon.textContent = icon;
  }

  if (toastMessage) {
    toastMessage.textContent = message;
  }

  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

/* ===== LOADING ===== */

function showLoading(text = "Загрузка...") {
  const overlay = getElement("loadingOverlay");
  const textElement = getElement("loadingText");

  if (textElement) {
    textElement.textContent = text;
  }

  if (overlay) {
    overlay.classList.remove("hidden");
  }
}

function hideLoading() {
  const overlay = getElement("loadingOverlay");

  if (overlay) {
    overlay.classList.add("hidden");
  }
}

/* ===== ARCHIVE ===== */

function renderArchive() {
  const list = getElement("archiveList");
  const emptyState = getElement("archiveEmptyState");
  const count = getElement("archiveCount");

  if (count) {
    count.textContent = String(state.archive.length);
  }

  if (!list) {
    return;
  }

  list.innerHTML = "";

  if (state.archive.length === 0) {
    if (emptyState) {
      emptyState.classList.remove("hidden");
    }

    return;
  }

  if (emptyState) {
    emptyState.classList.add("hidden");
  }

  const archived = sortTaskArray(
    state.archive,
    "newest"
  );

  archived.forEach(task => {
    const item = document.createElement("article");

    item.className = "archive-item";
    item.dataset.taskId = task.id;

    item.innerHTML = `
      <div class="archive-item-info">
        <div class="archive-item-title">
          ${escapeHtml(task.title)}
        </div>
        <div class="archive-item-meta">
          ${escapeHtml(getCategoryName(task.category))}
          ·
          ${escapeHtml(formatDate(task.createdAt))}
        </div>
      </div>

      <div class="archive-item-actions">
        <button
          type="button"
          class="icon-button"
          data-archive-action="restore"
          aria-label="Восстановить"
        >
          ↩️
        </button>

        <button
          type="button"
          class="icon-button danger"
          data-archive-action="delete"
          aria-label="Удалить навсегда"
        >
          🗑️
        </button>
      </div>
    `;

    list.appendChild(item);
  });
}

/* ===== ARCHIVE ACTIONS ===== */

function restoreArchiveTask(taskId) {
  const index = state.archive.findIndex(
    task => task.id === taskId
  );

  if (index === -1) {
    return;
  }

  const [task] = state.archive.splice(index, 1);

  task.completed = false;
  task.completedAt = null;
  task.updatedAt = Date.now();

  state.tasks.push(task);

  saveState();
  renderAll();

  showToast(
    "↩️",
    "Задача восстановлена"
  );
}

function requestDeleteArchiveTask(taskId) {
  const task = getArchiveTask(taskId);

  if (!task) {
    return;
  }

  confirmAction = {
    type: "deleteArchiveTask",
    taskId
  };

  openConfirmModal(
    "Удалить навсегда?",
    `«${task.title}» будет удалена без возможности восстановления.`
  );
}

function deleteArchiveTask(taskId) {
  const index = state.archive.findIndex(
    task => task.id === taskId
  );

  if (index === -1) {
    return;
  }

  state.archive.splice(index, 1);

  saveState();
  renderArchive();

  showToast(
    "🗑️",
    "Удалено из архива"
  );
}

/* ===== END BLOCK 5 ===== */
/* ===== CLEAR COMPLETED ===== */

function requestClearCompleted() {
  const completed = getCompletedCount();

  if (completed === 0) {
    showToast("✓", "Выполненных задач нет");
    return;
  }

  confirmAction = {
    type: "clearCompleted"
  };

  openConfirmModal(
    "Очистить выполненные?",
    `В архив будет перемещено задач: ${completed}.`
  );
}

function clearCompletedTasks() {
  const completed = state.tasks.filter(
    task => task.completed
  );

  if (completed.length === 0) {
    return;
  }

  const active = state.tasks.filter(
    task => !task.completed
  );

  state.archive.push(
    ...completed.map(task => ({
      ...task,
      updatedAt: Date.now()
    }))
  );

  state.tasks = active;

  saveState();
  renderAll();

  showToast(
    "📦",
    `В архив перемещено: ${completed.length}`
  );
}

/* ===== ARCHIVE CLEAR ===== */

function requestClearArchive() {
  if (state.archive.length === 0) {
    showToast("✓", "Архив уже пуст");
    return;
  }

  confirmAction = {
    type: "clearArchive"
  };

  openConfirmModal(
    "Очистить архив?",
    "Все задачи из архива будут удалены навсегда."
  );
}

function clearArchive() {
  state.archive = [];

  saveState();
  renderArchive();

  showToast(
    "🗑️",
    "Архив очищен"
  );
}

/* ===== SORTING ===== */

function openSortModal() {
  $$(".sort-option").forEach(option => {
    option.classList.toggle(
      "active",
      option.dataset.sort === currentSort
    );
  });

  openModal("sortModal");
}

function setSort(sortType) {
  const allowed = [
    "newest",
    "oldest",
    "completed",
    "alphabetical"
  ];

  if (!allowed.includes(sortType)) {
    return;
  }

  currentSort = sortType;
  state.settings.sort = sortType;

  saveState();
  renderTaskList();
  updateSortText();

  closeModal("sortModal");
}

function updateSortText() {
  const names = {
    newest: "Сначала новые",
    oldest: "Сначала старые",
    completed: "Сначала активные",
    alphabetical: "По алфавиту"
  };

  const text = names[currentSort] || names.newest;

  const button = getElement("sortSettingsValue");

  if (button) {
    button.textContent = text;
  }
}

/* ===== CATEGORY FILTER ===== */

function selectCategory(categoryId) {
  if (
    categoryId !== "all" &&
    !getCategory(categoryId)
  ) {
    return;
  }

  currentCategory = categoryId;

  $$(".category-card").forEach(card => {
    card.classList.toggle(
      "active",
      card.dataset.category === categoryId
    );
  });

  renderTaskList();
}

/* ===== CATEGORY CHOICE ===== */

function openCategoryChoice(taskId) {
  const task = getTask(taskId);

  if (!task) {
    return;
  }

  const list = getElement("categoryChoiceList");

  if (!list) {
    return;
  }

  list.innerHTML = "";

  state.categories.forEach(category => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "category-choice";
    button.dataset.category = category.id;

    if (category.id === task.category) {
      button.classList.add("active");
    }

    button.innerHTML = `
      <span>${escapeHtml(category.icon)}</span>
      <span>${escapeHtml(category.name)}</span>
    `;

    list.appendChild(button);
  });

  selectedTaskId = taskId;

  openModal("categoryChoiceModal");
}

function changeTaskCategory(categoryId) {
  if (!selectedTaskId) {
    return;
  }

  const task = getTask(selectedTaskId);

  if (!task || !getCategory(categoryId)) {
    return;
  }

  task.category = categoryId;
  task.updatedAt = Date.now();

  saveState();
  renderAll();
  closeModal("categoryChoiceModal");

  showToast(
    "📁",
    "Категория изменена"
  );
}

/* ===== END BLOCK 6 ===== */
/* ===== SEARCH ===== */

function openSearchScreen() {
  showScreen("search");
  renderSearchResults();

  const input = getElement("searchInput");

  if (input) {
    setTimeout(() => {
      input.focus();
    }, 50);
  }
}

function handleSearchInput() {
  const input = getElement("searchInput");

  searchQuery = input
    ? input.value.trim().toLowerCase()
    : "";

  const clearButton = getElement("clearSearchButton");

  if (clearButton) {
    clearButton.classList.toggle(
      "hidden",
      !searchQuery
    );
  }

  renderSearchResults();
}

function clearSearch() {
  const input = getElement("searchInput");

  searchQuery = "";

  if (input) {
    input.value = "";
    input.focus();
  }

  const clearButton = getElement("clearSearchButton");

  if (clearButton) {
    clearButton.classList.add("hidden");
  }

  renderSearchResults();
}

function renderSearchResults() {
  const container = getElement("searchResults");

  if (!container) {
    return;
  }

  container.innerHTML = "";

  if (!searchQuery) {
    const hint = document.createElement("div");

    hint.className = "empty-state";
    hint.innerHTML = `
      <div class="empty-icon">🔎</div>
      <h3>Поиск задач</h3>
      <p>Начни вводить название задачи.</p>
    `;

    container.appendChild(hint);
    return;
  }

  const results = state.tasks.filter(task => {
    const title = task.title.toLowerCase();
    const category = getCategoryName(
      task.category
    ).toLowerCase();

    return (
      title.includes(searchQuery) ||
      category.includes(searchQuery)
    );
  });

  if (results.length === 0) {
    const empty = document.createElement("div");

    empty.className = "empty-state";
    empty.innerHTML = `
      <div class="empty-icon">😕</div>
      <h3>Ничего не найдено</h3>
      <p>Попробуй изменить поисковый запрос.</p>
    `;

    container.appendChild(empty);
    return;
  }

  sortTaskArray(
    results,
    currentSort
  ).forEach(task => {
    container.appendChild(
      createTaskElement(task)
    );
  });
}

/* ===== TIPS ===== */

function renderTip() {
  const tip = getElement("dailyTip");

  if (!tip) {
    return;
  }

  const safeIndex =
    ((state.tipIndex % DEFAULT_TIPS.length) +
      DEFAULT_TIPS.length) %
    DEFAULT_TIPS.length;

  tip.textContent = DEFAULT_TIPS[safeIndex];
}

function nextTip() {
  state.tipIndex =
    (state.tipIndex + 1) %
    DEFAULT_TIPS.length;

  saveState();
  renderTip();
}

/* ===== SETTINGS RENDER ===== */

function renderSettings() {
  const darkToggle =
    getElement("darkThemeToggle");

  const animationsToggle =
    getElement("animationsToggle");

  const defaultCategoryValue =
    getElement("defaultCategoryValue");

  const sortValue =
    getElement("sortSettingsValue");

  const startScreenValue =
    getElement("startScreenValue");

  if (darkToggle) {
    darkToggle.checked =
      Boolean(state.settings.darkTheme);
  }

  if (animationsToggle) {
    animationsToggle.checked =
      Boolean(state.settings.animations);
  }

  if (defaultCategoryValue) {
    defaultCategoryValue.textContent =
      `${getCategoryIcon(state.settings.defaultCategory)} ` +
      getCategoryName(state.settings.defaultCategory);
  }

  if (sortValue) {
    const names = {
      newest: "Сначала новые",
      oldest: "Сначала старые",
      completed: "Сначала активные",
      alphabetical: "По алфавиту"
    };

    sortValue.textContent =
      names[state.settings.sort] ||
      names.newest;
  }

  if (startScreenValue) {
    startScreenValue.textContent =
      state.settings.startScreen === "settings"
        ? "Настройки"
        : "Главная";
  }
}

/* ===== SETTINGS: THEME ===== */

function setDarkTheme(enabled) {
  state.settings.darkTheme = Boolean(enabled);

  applySettings();
  saveState();
}

/* ===== SETTINGS: ANIMATIONS ===== */

function setAnimations(enabled) {
  state.settings.animations = Boolean(enabled);

  applySettings();
  saveState();
}

/* ===== DEFAULT CATEGORY ===== */

function openDefaultCategoryChoice() {
  const list = getElement("categoryChoiceList");

  if (!list) {
    return;
  }

  list.innerHTML = "";

  state.categories.forEach(category => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "category-choice";

    if (
      category.id ===
      state.settings.defaultCategory
    ) {
      button.classList.add("active");
    }

    button.dataset.category =
      category.id;

    button.innerHTML = `
      <span>${escapeHtml(category.icon)}</span>
      <span>${escapeHtml(category.name)}</span>
    `;

    button.addEventListener(
      "click",
      () => {
        state.settings.defaultCategory =
          category.id;

        saveState();
        renderSettings();
        closeModal("categoryChoiceModal");

        showToast(
          "📁",
          "Категория по умолчанию изменена"
        );
      }
    );

    list.appendChild(button);
  });

  openModal("categoryChoiceModal");
}

/* ===== END BLOCK 7 ===== */
/* ===== START SCREEN ===== */

function setStartScreen(screenName) {
  const allowed = ["home", "settings"];

  if (!allowed.includes(screenName)) {
    return;
  }

  state.settings.startScreen = screenName;

  saveState();
  renderSettings();

  showToast(
    "🏠",
    screenName === "home"
      ? "Стартовый экран: Главная"
      : "Стартовый экран: Настройки"
  );
}

function openStartScreenChoice() {
  const choice = window.confirm(
    "Открывать при запуске настройки?\n\n" +
    "OK — Настройки\n" +
    "Отмена — Главная"
  );

  setStartScreen(
    choice ? "settings" : "home"
  );
}

/* ===== CATEGORIES MANAGER ===== */

function renderCategoriesManager() {
  const list = getElement("manageCategoryList");

  if (!list) {
    return;
  }

  list.innerHTML = "";

  state.categories.forEach(category => {
    const item = document.createElement("div");

    item.className = "category-manager-item";
    item.dataset.categoryId = category.id;

    const isDefault =
      DEFAULT_CATEGORIES.some(
        item => item.id === category.id
      );

    item.innerHTML = `
      <div class="category-manager-info">
        <span class="category-manager-icon">
          ${escapeHtml(category.icon)}
        </span>

        <span class="category-manager-name">
          ${escapeHtml(category.name)}
        </span>
      </div>

      <div class="category-manager-actions">
        <button
          type="button"
          class="icon-button"
          data-category-action="rename"
          aria-label="Переименовать категорию"
        >
          ✏️
        </button>

        ${
          isDefault
            ? ""
            : `
              <button
                type="button"
                class="icon-button danger"
                data-category-action="delete"
                aria-label="Удалить категорию"
              >
                🗑️
              </button>
            `
        }
      </div>
    `;

    list.appendChild(item);
  });
}

function addCategory() {
  const input = getElement("newCategoryInput");

  if (!input) {
    return;
  }

  const name = input.value.trim();

  if (!name) {
    showMessage(
      "Пустое название",
      "Введите название новой категории."
    );
    return;
  }

  const exists = state.categories.some(
    category =>
      category.name.toLowerCase() ===
      name.toLowerCase()
  );

  if (exists) {
    showMessage(
      "Категория уже есть",
      "Категория с таким названием уже существует."
    );
    return;
  }

  state.categories.push({
    id: createId(),
    name,
    icon: "📁"
  });

  input.value = "";

  saveState();
  renderAll();

  showToast(
    "📁",
    "Категория добавлена"
  );
}

function renameCategory(categoryId) {
  const category = getCategory(categoryId);

  if (!category) {
    return;
  }

  const name = window.prompt(
    "Новое название категории:",
    category.name
  );

  if (name === null) {
    return;
  }

  const cleanName = name.trim();

  if (!cleanName) {
    showMessage(
      "Пустое название",
      "Название категории не может быть пустым."
    );
    return;
  }

  const duplicate = state.categories.some(
    item =>
      item.id !== categoryId &&
      item.name.toLowerCase() ===
      cleanName.toLowerCase()
  );

  if (duplicate) {
    showMessage(
      "Категория уже есть",
      "Такое название уже используется."
    );
    return;
  }

  category.name = cleanName;

  saveState();
  renderAll();

  showToast(
    "✏️",
    "Категория переименована"
  );
}

function requestDeleteCategory(categoryId) {
  const category = getCategory(categoryId);

  if (!category) {
    return;
  }

  if (
    DEFAULT_CATEGORIES.some(
      item => item.id === categoryId
    )
  ) {
    showMessage(
      "Нельзя удалить",
      "Стандартные категории нельзя удалить."
    );
    return;
  }

  const taskCount = getCategoryCount(categoryId);

  confirmAction = {
    type: "deleteCategory",
    categoryId
  };

  openConfirmModal(
    "Удалить категорию?",
    taskCount > 0
      ? `Задач в этой категории: ${taskCount}. Они будут перенесены в «Личное».`
      : `Категория «${category.name}» будет удалена.`
  );
}

function deleteCategory(categoryId) {
  const category = getCategory(categoryId);

  if (!category) {
    return;
  }

  if (
    DEFAULT_CATEGORIES.some(
      item => item.id === categoryId
    )
  ) {
    return;
  }

  state.tasks.forEach(task => {
    if (task.category === categoryId) {
      task.category = "personal";
      task.updatedAt = Date.now();
    }
  });

  state.archive.forEach(task => {
    if (task.category === categoryId) {
      task.category = "personal";
      task.updatedAt = Date.now();
    }
  });

  state.categories =
    state.categories.filter(
      item => item.id !== categoryId
    );

  if (
    state.settings.defaultCategory ===
    categoryId
  ) {
    state.settings.defaultCategory =
      "personal";
  }

  if (currentCategory === categoryId) {
    currentCategory = "all";
  }

  saveState();
  renderAll();

  showToast(
    "🗑️",
    "Категория удалена"
  );
}

/* ===== END BLOCK 8 ===== */
/* ===== DATA EXPORT ===== */

function exportData() {
  try {
    const data = {
      app: "QuickList",
      version: 1,
      exportedAt: new Date().toISOString(),
      data: state
    };

    const json = JSON.stringify(
      data,
      null,
      2
    );

    const blob = new Blob(
      [json],
      { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download =
      `quicklist-backup-${formatFileDate()}.json`;

    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);

    showToast(
      "💾",
      "Данные экспортированы"
    );
  } catch (error) {
    console.error(
      "QuickList: ошибка экспорта",
      error
    );

    showMessage(
      "Ошибка",
      "Не удалось экспортировать данные."
    );
  }
}

function formatFileDate() {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(
    now.getMonth() + 1
  ).padStart(2, "0");
  const day = String(
    now.getDate()
  ).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

/* ===== DATA IMPORT ===== */

function openImportPicker() {
  const input = getElement("importFileInput");

  if (!input) {
    return;
  }

  input.value = "";
  input.click();
}

async function importDataFromFile(event) {
  const input = event.target;
  const file = input.files?.[0];

  if (!file) {
    return;
  }

  try {
    showLoading("Импорт данных...");

    const text = await file.text();
    const parsed = JSON.parse(text);

    const importedData =
      parsed && parsed.data
        ? parsed.data
        : parsed;

    const normalized =
      normalizeState(importedData);

    if (
      !Array.isArray(normalized.tasks) ||
      !Array.isArray(normalized.categories)
    ) {
      throw new Error(
        "Некорректный формат данных"
      );
    }

    state = normalized;

    currentCategory = "all";
    selectedTaskId = null;
    editingTaskId = null;
    currentSort =
      state.settings.sort || "newest";

    saveState();
    applySettings();
    renderAll();

    hideLoading();

    showToast(
      "📥",
      "Данные импортированы"
    );
  } catch (error) {
    console.error(
      "QuickList: ошибка импорта",
      error
    );

    hideLoading();

    showMessage(
      "Ошибка импорта",
      "Файл не удалось прочитать. " +
      "Убедись, что это корректный JSON-файл QuickList."
    );
  } finally {
    if (input) {
      input.value = "";
    }
  }
}

/* ===== RESET ===== */

function requestResetData() {
  confirmAction = {
    type: "resetData"
  };

  openConfirmModal(
    "Сбросить QuickList?",
    "Все задачи, категории, архив и настройки будут удалены."
  );
}

function resetData() {
  state = createDefaultState();

  currentScreen = "home";
  currentCategory = "all";
  selectedTaskId = null;
  editingTaskId = null;
  currentSort = "newest";
  searchQuery = "";
  tipIndex = 0;

  saveState();
  applySettings();
  closeAllModals();
  renderAll();
  showScreen("home");

  showToast(
    "↻",
    "Данные сброшены"
  );
}

/* ===== DONATION / INFO ===== */

function openDonationInfo() {
  showMessage(
    "Спасибо ❤️",
    "QuickList создан как простой и удобный проект. " +
    "Спасибо за поддержку!"
  );
}

/* ===== CONFIRM ACTION EXTENSION ===== */

function executeExtendedConfirmAction() {
  if (!confirmAction) {
    closeModal("confirmModal");
    return;
  }

  const action = confirmAction;
  confirmAction = null;

  closeModal("confirmModal");

  switch (action.type) {
    case "deleteTask":
      deleteTask(action.taskId);
      break;

    case "clearCompleted":
      clearCompletedTasks();
      break;

    case "clearArchive":
      clearArchive();
      break;

    case "resetData":
      resetData();
      break;

    case "deleteArchiveTask":
      deleteArchiveTask(action.taskId);
      break;

    case "deleteCategory":
      deleteCategory(action.categoryId);
      break;

    default:
      break;
  }
}

/* ===== END BLOCK 9 ===== */
/* ===== EVENT LISTENERS ===== */

function setupEventListeners() {
  const addButton = getElement("addTaskButton");
  const taskInput = getElement("taskInput");

  if (addButton) {
    addButton.addEventListener("click", () => {
      if (taskInput && taskInput.value.trim()) {
        addTask(
          taskInput.value,
          state.settings.defaultCategory
        );

        taskInput.value = "";
      } else {
        openAddTaskModal();
      }
    });
  }

  if (taskInput) {
    taskInput.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        addButton?.click();
      }
    });
  }

  getElement("navAddButton")
    ?.addEventListener(
      "click",
      openAddTaskModal
    );

  getElement("searchButton")
    ?.addEventListener(
      "click",
      openSearchScreen
    );

  getElement("closeSearchButton")
    ?.addEventListener(
      "click",
      () => showScreen("home")
    );

  getElement("searchInput")
    ?.addEventListener(
      "input",
      handleSearchInput
    );

  getElement("clearSearchButton")
    ?.addEventListener(
      "click",
      clearSearch
    );

  getElement("sortTasksButton")
    ?.addEventListener(
      "click",
      openSortModal
    );

  getElement("emptyAddButton")
    ?.addEventListener(
      "click",
      openAddTaskModal
    );

  getElement("clearCompletedButton")
    ?.addEventListener(
      "click",
      requestClearCompleted
    );

  getElement("archiveTasksButton")
    ?.addEventListener(
      "click",
      () => showScreen("archive")
    );

  getElement("settingsButton")
    ?.addEventListener(
      "click",
      () => showScreen("settings")
    );

  getElement("nextTipButton")
    ?.addEventListener(
      "click",
      nextTip
    );

  getElement("closeArchiveButton")
    ?.addEventListener(
      "click",
      () => showScreen("home")
    );

  getElement("clearArchiveButton")
    ?.addEventListener(
      "click",
      requestClearArchive
    );

  getElement("closeSettingsButton")
    ?.addEventListener(
      "click",
      () => showScreen("home")
    );

  getElement("closeCategoriesButton")
    ?.addEventListener(
      "click",
      () => showScreen("settings")
    );

  getElement("settingsManageCategoriesButton")
    ?.addEventListener(
      "click",
      () => showScreen("categories")
    );

  getElement("manageCategoriesButton")
    ?.addEventListener(
      "click",
      () => showScreen("categories")
    );

  getElement("addCategoryButton")
    ?.addEventListener(
      "click",
      addCategory
    );

  getElement("newCategoryInput")
    ?.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        addCategory();
      }
    });

  getElement("darkThemeToggle")
    ?.addEventListener(
      "change",
      event => setDarkTheme(
        event.target.checked
      )
    );

  getElement("animationsToggle")
    ?.addEventListener(
      "change",
      event => setAnimations(
        event.target.checked
      )
    );

  getElement("defaultCategoryButton")
    ?.addEventListener(
      "click",
      openDefaultCategoryChoice
    );

  getElement("sortSettingsButton")
    ?.addEventListener(
      "click",
      openSortModal
    );

  getElement("startScreenButton")
    ?.addEventListener(
      "click",
      openStartScreenChoice
    );

  getElement("exportDataButton")
    ?.addEventListener(
      "click",
      exportData
    );

  getElement("importDataButton")
    ?.addEventListener(
      "click",
      openImportPicker
    );

  getElement("importFileInput")
    ?.addEventListener(
      "change",
      importDataFromFile
    );

  getElement("resetDataButton")
    ?.addEventListener(
      "click",
      requestResetData
    );

  getElement("donateButton")
    ?.addEventListener(
      "click",
      openDonationInfo
    );

  getElement("closeTaskDetailsButton")
    ?.addEventListener(
      "click",
      () => showScreen("home")
    );

  getElement("toggleTaskDetailsButton")
    ?.addEventListener(
      "click",
      toggleSelectedTask
    );

  getElement("editTaskButton")
    ?.addEventListener(
      "click",
      editSelectedTask
    );

  getElement("deleteTaskButton")
    ?.addEventListener(
      "click",
      deleteSelectedTask
    );

  getElement("saveTaskButton")
    ?.addEventListener(
      "click",
      saveModalTask
    );

  getElement("saveEditTaskButton")
    ?.addEventListener(
      "click",
      saveEditedTask
    );

  getElement("cancelConfirmButton")
    ?.addEventListener(
      "click",
      () => {
        confirmAction = null;
        closeModal("confirmModal");
      }
    );

  getElement("confirmDeleteButton")
    ?.addEventListener(
      "click",
      executeExtendedConfirmAction
    );

  getElement("closeMessageButton")
    ?.addEventListener(
      "click",
      () => closeModal("messageModal")
    );

  getElement("messageOkButton")
    ?.addEventListener(
      "click",
      () => closeModal("messageModal")
    );
}

/* ===== FORM EVENTS ===== */

function setupFormListeners() {
  getElement("addTaskForm")
    ?.addEventListener("submit", event => {
      event.preventDefault();
      saveModalTask();
    });

  getElement("editTaskForm")
    ?.addEventListener("submit", event => {
      event.preventDefault();
      saveEditedTask();
    });
}

/* ===== CLICK DELEGATION ===== */

function setupDelegatedEvents() {
  document.addEventListener("click", event => {
    const categoryCard =
      event.target.closest(".category-card");

    if (categoryCard) {
      selectCategory(
        categoryCard.dataset.category
      );
      return;
    }

    const taskAction =
      event.target.closest("[data-action]");

    if (taskAction) {
      const taskItem =
        taskAction.closest(".task-item");

      if (!taskItem) {
        return;
      }

      const taskId =
        taskItem.dataset.taskId;

      switch (taskAction.dataset.action) {
        case "toggle":
          toggleTask(taskId);
          break;

        case "details":
          openTaskDetails(taskId);
          break;

        case "edit":
          openEditTask(taskId);
          break;

        case "delete":
          requestDeleteTask(taskId);
          break;

        default:
          break;
      }

      return;
    }

    const archiveAction =
      event.target.closest(
        "[data-archive-action]"
      );

    if (archiveAction) {
      const item =
        archiveAction.closest(".archive-item");

      if (!item) {
        return;
      }

      const taskId = item.dataset.taskId;

      if (
        archiveAction.dataset.archiveAction ===
        "restore"
      ) {
        restoreArchiveTask(taskId);
      } else {
        requestDeleteArchiveTask(taskId);
      }

      return;
    }

    const sortOption =
      event.target.closest(".sort-option");

    if (sortOption) {
      setSort(sortOption.dataset.sort);
      return;
    }

    const categoryChoice =
      event.target.closest(
        ".category-choice"
      );

    if (
      categoryChoice &&
      selectedTaskId
    ) {
      changeTaskCategory(
        categoryChoice.dataset.category
      );

      return;
    }

    const categoryAction =
      event.target.closest(
        "[data-category-action]"
      );

    if (categoryAction) {
      const item =
        categoryAction.closest(
          ".category-manager-item"
        );

      if (!item) {
        return;
      }

      const categoryId =
        item.dataset.categoryId;

      if (
        categoryAction.dataset.categoryAction ===
        "rename"
      ) {
        renameCategory(categoryId);
      } else {
        requestDeleteCategory(categoryId);
      }
    }
  });
}

/* ===== CLOSE BUTTONS ===== */

function setupModalCloseEvents() {
  $$("[data-close-modal]").forEach(button => {
    button.addEventListener("click", () => {
      closeModal(
        button.dataset.closeModal
      );
    });
  });

  $$(".modal").forEach(modal => {
    modal.addEventListener("click", event => {
      if (event.target === modal) {
        closeModal(modal.id);
      }
    });
  });
}

/* ===== BOTTOM NAV ===== */

function setupNavigation() {
  $$(".nav-item").forEach(item => {
    item.addEventListener("click", () => {
      const screen =
        item.dataset.screen;

      if (screen) {
        showScreen(screen);
      }
    });
  });
}

/* ===== KEYBOARD ===== */

function setupKeyboard() {
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      closeAllModals();
    }
  });
}

/* ===== INITIALIZATION ===== */

function initializeApp() {
  loadState();

  currentSort =
    state.settings.sort || "newest";

  tipIndex =
    Number.isInteger(state.tipIndex)
      ? state.tipIndex
      : 0;

  applySettings();
  setupEventListeners();
  setupFormListeners();
  setupDelegatedEvents();
  setupModalCloseEvents();
  setupNavigation();
  setupKeyboard();

  renderAll();

  showScreen(
    state.settings.startScreen === "settings"
      ? "settings"
      : "home"
  );

  hideLoading();
}

/* ===== START ===== */

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeApp,
    { once: true }
  );
} else {
  initializeApp();
}

/* ===== END OF QUICKLIST ===== */