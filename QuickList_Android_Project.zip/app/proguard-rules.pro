# QuickList release rules
