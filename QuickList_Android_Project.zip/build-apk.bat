@echo off
echo Open this project in Android Studio and sync Gradle first.
echo Then use: Build ^> Build APK(s)
pause
