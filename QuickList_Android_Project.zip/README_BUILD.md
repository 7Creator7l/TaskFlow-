# QuickList — Android project

This project wraps the CodePen `dist` version of QuickList in a native Android WebView.

Package: `com.recre.quicklist`
Version: `1.0` (versionCode 1)

## Build APK
Open this folder in Android Studio, let Gradle sync, then:
Build → Build Bundle(s) / APK(s) → Build APK(s)

## Build AAB
Build → Generate Signed Bundle / APK → Android App Bundle

For Google Play, create/use a release keystore and keep the keystore and passwords private.

The web app files are in:
`app/src/main/assets/`

The generated QuickList icon is already included.
