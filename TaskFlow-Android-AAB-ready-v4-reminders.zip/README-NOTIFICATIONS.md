# TaskFlow notifications v3

This version adds native Android task reminders. When a TaskFlow task is created or edited with a future date/time, the Android wrapper schedules a reminder. Completing or deleting a task cancels its reminder. The app uses AlarmManager.setAndAllowWhileIdle, so delivery may be slightly delayed by Android power management.


### Reminder timing
TaskFlow prefers exact Android alarms when the device grants the special **Alarms & reminders** access. If that access is unavailable, it safely falls back to Android's idle-safe inexact alarm, which may be delayed by the system.
