# TaskFlow notifications v3

This version adds native Android task reminders. When a TaskFlow task is created or edited with a future date/time, the Android wrapper schedules a reminder. Completing or deleting a task cancels its reminder. The app uses AlarmManager.setAndAllowWhileIdle, so delivery may be slightly delayed by Android power management.
